var siteinfo = {
    'acid': -1,
    'version': '1.0.0',
    'siteroot': 'https://www.abc.com/app/index.php',
    'apiroot': 'https://slct.test/web/index.php?store_id=8&r=api/',
};
module.exports = siteinfo;