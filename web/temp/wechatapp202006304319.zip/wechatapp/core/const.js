var _module$exports;

function _defineProperty(e, _, r) {
    return _ in e ? Object.defineProperty(e, _, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[_] = r, e;
}

module.exports = (_defineProperty(_module$exports = {
    FORM_ID_LIST: "FORM_ID_LIST",
    LOGIN_PRE_PAGE: "LOGIN_PRE_PAGE",
    NAVIGATION_BAR_COLOR: "NAVIGATION_BAR_COLOR",
    WX_BAR_TITLE: "WX_BAR_TITLE",
    USER_INFO: "USER_INFO",
    STORE_CONFIG: "STORE_CONFIG",
    STORE: "STORE",
    STORE_NAME: "STORE_NAME",
    SHOW_CUSTOMER_SERVICE: "SHOW_CUSTOMER_SERVICE",
    CONTACT_TEL: "CONTACT_TEL",
    SHARE_SETTING: "SHARE_SETTING",
    WXAPP_IMG: "WXAPP_IMG"
}, "WX_BAR_TITLE", "WX_BAR_TITLE"), _defineProperty(_module$exports, "ALIPAY_MP_CONFIG", "ALIPAY_MP_CONFIG"), 
_defineProperty(_module$exports, "PAGE_INDEX_INDEX", "PAGE_INDEX_INDEX"), _defineProperty(_module$exports, "ITEM", "ITEM"), 
_defineProperty(_module$exports, "CAT_LIST", "CAT_LIST"), _defineProperty(_module$exports, "LIST_PAGE_RELOAD", "LIST_PAGE_RELOAD"), 
_defineProperty(_module$exports, "LIST_PAGE_OPTIONS", "LIST_PAGE_OPTIONS"), _defineProperty(_module$exports, "PICKER_ADDRESS", "PICKER_ADDRESS"), 
_defineProperty(_module$exports, "DISTRICT", "DISTRICT"), _defineProperty(_module$exports, "CUSTOM", "CUSTOM"), 
_defineProperty(_module$exports, "DISTRICT", "DISTRICT"), _defineProperty(_module$exports, "INPUT_DATA", "INPUT_DATA"), 
_defineProperty(_module$exports, "PAGES_USER_USER", "PAGES_USER_USER"), _defineProperty(_module$exports, "SEARCH_HISTORY_LIST", "SEARCH_HISTORY_LIST"), 
_defineProperty(_module$exports, "PT_GROUP_DETAIL", "PT_GROUP_DETAIL"), _defineProperty(_module$exports, "HISTORY_INFO", "HISTORY_INFO"), 
_defineProperty(_module$exports, "CURRENT_DAY_LIST", "CURRENT_DAY_LIST"), _defineProperty(_module$exports, "ACCESS_TOKEN", "ACCESS_TOKEN"), 
_defineProperty(_module$exports, "QUICK_LIST", "QUICK_LIST"), _defineProperty(_module$exports, "QUICK_LISTS", "QUICK_LISTS"), 
_defineProperty(_module$exports, "CARGOODS", "CARGOODS"), _defineProperty(_module$exports, "TOTAL", "TOTAL"), 
_defineProperty(_module$exports, "CHECK_NUM", "CHECK_NUM"), _defineProperty(_module$exports, "QUICK_HOT_GOODS_LISTS", "QUICK_HOT_GOODS_LISTS"), 
_defineProperty(_module$exports, "PARENT_ID", "PARENT_ID"), _defineProperty(_module$exports, "NAVIGATION_BAR_COLOR", "NAVIGATION_BAR_COLOR"), 
_module$exports);